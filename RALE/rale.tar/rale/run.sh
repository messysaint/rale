java -cp .:lib/util.jar:lib/jecf.jar  mainClass &

