/*
 * RALEConstants.java
 *
 * Created on February 3, 2004, 7:31 PM
 */

package com.likhasoftware.rale.util;

/**
 *
 * @author  Administrator
 */
public class RALEConstants {
    
    static String fs = System.getProperty( "file.separator" );
    
    /** Creates a new instance of RALEConstants */
    public RALEConstants() {
    }
    
    public static String getFileSeparator() {
        return fs;
    }
    
    
}
