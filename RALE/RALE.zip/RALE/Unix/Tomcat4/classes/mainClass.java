/*
 * mainClass.java
 *
 * Created on April 6, 2003, 11:43 AM
 */
import loader.*;
/**
 *
 * @author  test1
 */
public class mainClass {
    
    /** Creates a new instance of mainClass */
    public mainClass() {
    }
    
    /**
     * @param args the command line arguments
     */   
    public static void main(String args[]) {
        
        loader s  = new loader();
        s.run();
    }
    
}
