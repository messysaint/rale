java -cp .:util.jar mainClass

